var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var session = require('express-session');
var path = require('path');
var indexRouter = require('./routers/index.js');
var taikhoanRouter = require('./routers/taikhoan.js');
var monhocRouter = require('./routers/monhoc.js');
var loginRouter = require('./routers/login.js');
var diemdanhRouter = require('./routers/diemdanh.js');
var xinnghiRouter = require('./routers/xinnghi.js');


var uri = 'mongodb+srv://admin:admin123456@cluster0.gcxaktx.mongodb.net/quanlisinhvien';
mongoose.connect(uri).catch(err => console.log(err));

app.set('views', './views');    
app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({   
    secret: 'yourSecretKey', // Khóa bí mật để ký session ID
    resave: false,           // Không lưu lại session nếu không thay đổi
    saveUninitialized: true, // Lưu session mới chưa được khởi tạo
    cookie: { secure: false } // Đặt là true nếu sử dụng HTTPS
}));

app.use((req, res, next) => {
    res.locals.session = req.session;
    
    var error = req.session.error;
    var success = req.session.success;
    
    delete req.session.error;
    delete req.session.success;
    
    res.locals.errorMsg = '';
    res.locals.successMsg = '';
    
    if (error) res.locals.errorMsg = error;
    if (success) res.locals.successMsg = success;
    
    next();
});

app.use('/', indexRouter);
app.use('/taikhoan', taikhoanRouter);
app.use('/dangnhap', loginRouter);
app.use('/monhoc', monhocRouter);
app.use('/diemdanh', diemdanhRouter);
app.use('/xinnghi', xinnghiRouter);




app.listen(8000, () => {
    console.log('Toi ten la toan');
}); 