const requireLogin = (req, res, next) => {
    if (!req.session.HoVaTen) {
        // Nếu không có thông tin đăng nhập trong session, chuyển hướng đến trang đăng nhập
        return res.redirect('/dangnhap');
    }
    // Nếu có thông tin đăng nhập trong session, tiếp tục xử lý yêu cầu
    next();
};

module.exports = requireLogin;