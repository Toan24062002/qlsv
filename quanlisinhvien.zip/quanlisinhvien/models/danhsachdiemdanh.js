var mongoose = require('mongoose');

var dsdiemDanhSchema = new mongoose.Schema({
    Madd: { type: String, required: true },
	MaMonHoc: { type: String, required: true },
	TenMonHoc: { type: String, required: true },
	MaSoSinhVien: { type: String, required: true },
	Ngay: { type: Date, required: true },
	TinhTrang: { type: String, default: 'có mặt' },
    HoTen: { type: String, required: true },
});	

var dsdiemDanhModel = mongoose.model('DsDiemDanh', dsdiemDanhSchema);

module.exports = dsdiemDanhModel;   