var mongoose = require('mongoose');

var diemDanhSchema = new mongoose.Schema({
	MaMonHoc: { type: String, required: true },
	GiangVien: { type: String, required: true },
	TenMonHoc: { type: String, required: true },
	Ngay: { type: Date, required: true },
	Nhom: { type: String, required: true },
    UserTao: { type: String, required: true },
	Pass: { type: String, required: true },
	Emailgv: { type: String, required: true },

});	

var diemDanhModel = mongoose.model('DiemDanh', diemDanhSchema);

module.exports = diemDanhModel;