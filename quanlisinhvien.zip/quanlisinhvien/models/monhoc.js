var mongoose = require('mongoose');

var monHocSchema = new mongoose.Schema({
	MaMonHoc: { type: String, required: true },
	TenMonHoc: { type: String, required: true },
	Nhom: { type: String, required: true },
    UserTao: { type: String, required: true },
});

var monHocModel = mongoose.model('MonHoc', monHocSchema);

module.exports = monHocModel;