var mongoose = require('mongoose');

var xinNghiSchema = new mongoose.Schema({
    Madd: { type: String, required: true },
	MaMonHoc: { type: String, required: true },
	GuiDen: { type: String, required: true },
	TenMonHoc: { type: String, required: true },
	Ngay: { type: Date, required: true },
	HoTen: { type: String, required: true },
    LiDo: { type: String, required: true },
    UserTao: { type: String, required: true },
	TinhTrang: { type: String, default: 'chưa duyệt'},
});	

var xinNghiModel = mongoose.model('XinNghi', xinNghiSchema);

module.exports = xinNghiModel;