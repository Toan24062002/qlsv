var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var saltRounds = 10;
var DiemDanh = require('../models/diemdanh');
var DsDiemDanh = require('../models/danhsachdiemdanh');
const nodemailer = require('nodemailer');
require ("dotenv").config();

router.get('/', async (req, res) => {
    var HoVaTen = req.session.TenDangNhap;
    var Ten = req.session.HoVaTen;
    var role = req.session.QuyenHan;
    res.render('home_layout', { 
        title: 'Điểm danh', 
        bodyContent: 'diemdanh',
        role:role,
        HoVaTen: HoVaTen,
        Ten:Ten,
    });
});
router.get('/dsdiemdanh', async (req, res) => {
    var HoVaTen = req.session.TenDangNhap;
    var Ten = req.session.HoVaTen;
    var role = req.session.QuyenHan;
    res.render('home_layout', { 
        title: 'Điểm danh', 
        bodyContent: 'dsdiemdanh',
        role:role,
        HoVaTen: HoVaTen,
        Ten:Ten,
    });
});
router.post('/them', async (req, res) => {
        var thoiGianHienTai = Date.now();
     req.session.email;
	var data = {
		MaMonHoc: req.body.maMonHoc,
        GiangVien: req.body.ten,
		TenMonHoc: req.body.tenMonHoc,
        Ngay: thoiGianHienTai,
		Nhom: req.body.nhom,
        Pass: req.body.pass,
        UserTao: req.body.tao,
        Emailgv: req.session.email,

	};
	await DiemDanh.create(data);
	res.redirect('/');

});
router.post('/dd', async (req, res) => {
    try {
        var diemdanh = await DiemDanh.findOne({_id: req.body.madd , MaMonHoc: req.body.mamonhoc  }).exec();
        if (diemdanh) {
            if (req.body.pass == diemdanh.Pass) {
                // Đăng ký session
                var thoiGianHienTai = Date.now();

                var data = {
                    Madd: req.body.madd,
                    MaMonHoc: req.body.mamonhoc,
                    TenMonHoc: req.body.tenmh,
                    MaSoSinhVien: req.session.TenDangNhap,
                    Ngay: thoiGianHienTai,
                    HoTen: req.session.HoVaTen,
                };
                await DsDiemDanh.create(data);
                 // Gửi email thông báo
                 const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
                        user: process.env.EMAIL_USER, 
                        pass: process.env.EMAIL_PASS 
                    }
                });
                var em = req.session.email;
                var ht = req.session.HoVaTen;
                var ms = req.session.TenDangNhap;
                var mh = req.body.tenmh;
                const mailOptions = {
                    from: 'quanlisinhvienagu@gmail.com', 
                    to: em, 
                    subject: 'Thông báo điểm danh', 
                    html: `
                        <p>Sinh viên: ${ht} - ${ms} đã điểm danh thành công môn ${mh}</p>`
                    
                };

                transporter.sendMail(mailOptions, function(error, info){
                    if (error) {
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                    }
                });

                res.redirect('/');
            } else {
                req.session.error = 'Mật khẩu không đúng.';
                res.redirect('/fssf');
            }
        } 
        else {
            req.session.error = 'Tên đăng nhập không tồn tại.';
            res.redirect('/fsf');    
        }
    } catch (error) {
        req.session.error = 'Đã xảy ra lỗi. Vui lòng thử lại.';
        res.redirect('/ff');
    }
});

module.exports = router;