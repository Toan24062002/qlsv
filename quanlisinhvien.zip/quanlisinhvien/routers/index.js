var express = require('express');
var router = express.Router();
var TaiKhoan = require ('../models/taikhoan');
var MonHoc = require ('../models/monhoc');
var DiemDanh = require('../models/diemdanh');
var DsDiemDanh = require('../models/danhsachdiemdanh');


const requireLogin = require('../middleware/checklogin');

router.get('/', async (req, res) => {
    var HoVaTen = req.session.TenDangNhap;
    var role = req.session.QuyenHan;
    var danhSachMonHoc = await MonHoc.find();
    var danhSachMonHocGV = await MonHoc.find({UserTao: HoVaTen});
    res.render('home_layout', { title: 'Trang chủ', bodyContent: 'home',HoVaTen: HoVaTen,role: role, danhSachMonHoc: danhSachMonHoc, danhSachMonHocGV:danhSachMonHocGV });
});
router.get('/hocphanchitiet/:id', async (req, res) => {
    var id = req.params.id;
    var HoVaTen = req.session.TenDangNhap;
    var Ten = req.session.HoVaTen;
    var role = req.session.QuyenHan;
    var danhSachMonHoc = await MonHoc.findById(id);
    var checkdd = await DsDiemDanh.find({HoTen: HoVaTen});
    var diemdanh = await DiemDanh.find({MaMonHoc: danhSachMonHoc.MaMonHoc})
    var layemai = await TaiKhoan.find({TenDangNhap: diemdanh.UserTao})
    res.render('home_layout', { title: 'Trang chủ', bodyContent: 'hocphan_chitiet',HoVaTen: HoVaTen,role: role, danhSachMonHoc: danhSachMonHoc , diemdanh: diemdanh,checkdd:checkdd,Ten:Ten, layemai:layemai });
});
router.get('/dangnhap', (req, res) => {
    res.render('login', { title: 'Login',});
});
router.get('/dsdiemdanh/:MaMonHoc/:id', async (req, res) => {
    var id = req.params.id;
    var mamh = req.params.MaMonHoc;
    var HoVaTen = req.session.TenDangNhap;
    var Ten = req.session.HoVaTen;
    var role = req.session.QuyenHan;
    var diemdanh = await DiemDanh.find({MaMonHoc: mamh})
    var danhsach = await DsDiemDanh.find({Madd:  id});
    res.render('home_layout', { 
        title: 'Điểm danh', 
        bodyContent: 'dsdiemdanh',
        role:role,
        HoVaTen: HoVaTen,
        Ten:Ten,
        danhsach:danhsach,
        diemdanh:diemdanh,

    });
});
// Thêm các route khác nếu cần'
router.get('/logout', (req, res) => {
    // Xóa thông tin phiên người dùng
    req.session.destroy(err => {
        if (err) {
            console.log('Lỗi khi đăng xuất:', err);
        } else {
            // Điều hướng người dùng đến trang đăng nhập sau khi đăng xuất thành công
            res.redirect('/dangnhap');
        }
    });
});

module.exports = router;
