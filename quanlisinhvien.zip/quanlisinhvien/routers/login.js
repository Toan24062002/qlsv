var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var TaiKhoan = require('../models/taikhoan');

// dang nhapa
router.get('/dangnhap',async (req,res) =>{
    res.render('login',{title:'Dang nhap'});
});

router.post('/login', async (req, res) => {
    try {
        var taikhoan = await TaiKhoan.findOne({ TenDangNhap: req.body.tendangnhap }).exec();
        if (taikhoan) {
            if (bcrypt.compareSync(req.body.matkhau, taikhoan.MatKhau)) {
                // Đăng ký session
                req.session.id = taikhoan._id;
                req.session.HoVaTen = taikhoan.HoVaTen;
                req.session.TenDangNhap = taikhoan.TenDangNhap;
                req.session.email = taikhoan.Email;
                req.session.QuyenHan = taikhoan.QuyenHan;
                res.redirect('/');
            } else {
                req.session.error = 'Mật khẩu không đúng.';
                res.redirect('/dangnhap');
            }
        } else {
            req.session.error = 'Tên đăng nhập không tồn tại.';
            res.redirect('/dangnhap');    
        }
    } catch (error) {
        req.session.error = 'Đã xảy ra lỗi. Vui lòng thử lại.';
        res.redirect('/dangnhap');
    }
});


module.exports = router; 