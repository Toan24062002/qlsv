var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var saltRounds = 10;
var MonHoc = require('../models/monhoc');
var DiemDanh = require('../models/diemdanh');

router.get('/', async (req, res) => {
    var HoVaTen = req.session.TenDangNhap;
    var Ten = req.session.HoVaTen;
    var role = req.session.QuyenHan;
    var danhSachMonHoc = await MonHoc.find({ UserTao: HoVaTen }).exec();
    res.render('home_layout', { 
        title: 'Môn học', 
        bodyContent: 'monhoc', 
        danhSachMonHoc: danhSachMonHoc,
        HoVaTen: HoVaTen,
        role:role,
        Ten: Ten
    });
});

router.post('/them', async (req, res) => {
	var data = {
		MaMonHoc: req.body.mamonhoc,
		TenMonHoc: req.body.tenmonhoc,
		Nhom: req.body.nhom,
        UserTao: req.body.tao,
	};
	await MonHoc.create(data);
	res.redirect('/monhoc');

});
router.post('/sua', async (req, res) => {
    const monHocId = req.body.id;
    const updatedData = {
        MaMonHoc: req.body.mamonhoc,
        TenMonHoc: req.body.tenmonhoc,
        Nhom: req.body.nhom,
        UserTao: req.body.tao,
    };

    await MonHoc.findByIdAndUpdate(monHocId, updatedData);

    res.redirect('/monhoc');
});

module.exports = router;