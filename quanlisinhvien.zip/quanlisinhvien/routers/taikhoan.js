var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var saltRounds = 10;
var TaiKhoan = require('../models/taikhoan');
const nodemailer = require('nodemailer');
require ("dotenv").config();
router.post('/them', async (req, res) => {
	var data = {
		HoVaTen: req.body.HoVaTen,
		Email: req.body.Email,
		TenDangNhap: req.body.TenDangNhap,
		MatKhau: bcrypt.hashSync(req.body.MatKhau, saltRounds)
	};
	await TaiKhoan.create(data);
	const transporter = nodemailer.createTransport({
		service: 'gmail',
		auth: {
			user: process.env.EMAIL_USER, 
			pass: process.env.EMAIL_PASS 
		}
	});
	var em = req.body.Email;
	var mk = req.body.MatKhau;
	var us = req.body.TenDangNhap;
	
	const mailOptions = {
		from: 'quanlisinhvienagu@gmail.com', 
		to: em, 
		subject: 'Thông báo', 
		html: `
			<h2>Đăng ký tài khoản thành công</h2>
			<p>Tên đăng nhập: ${us}.</p>
			<p>Mật khẩu: ${mk}</p>`

			
		
	};

	transporter.sendMail(mailOptions, function(error, info){
		if (error) {
			console.log(error);
		} else {
			console.log('Email sent: ' + info.response);
		}
	});
	res.redirect('/dangnhap');

});


module.exports = router;