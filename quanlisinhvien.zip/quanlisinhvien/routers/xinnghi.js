var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var saltRounds = 10;
var XinNghi = require('../models/xinnghi');
var DsDiemDanh = require('../models/danhsachdiemdanh');

router.post('/xpadd', async (req, res) => {
    var thoiGianHienTai = Date.now();
    
    var data = {

    Madd: req.body.madd,
	MaMonHoc: req.body.maamh ,
	GuiDen: req.body.guiden,
	TenMonHoc:  req.body.tenmonhoc  ,
	Ngay: thoiGianHienTai,
	HoTen: req.session.HoVaTen ,
    UserTao: req.session.TenDangNhap,
    LiDo: req.body.lido,

    };
    await XinNghi.create(data);
    var dataa = {
        Madd: req.body.maadd,
        MaMonHoc: req.body.maamh,
        TenMonHoc: req.body.tenmonhoc,
        MaSoSinhVien: req.session.TenDangNhap,
        Ngay: thoiGianHienTai,
        HoTen: req.session.HoVaTen,
        TinhTrang:"chưa duyệt"
    };
    await DsDiemDanh.create(dataa);
    res.redirect('/');

});


module.exports = router; 